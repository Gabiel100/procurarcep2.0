class Endereco:
    def __init__(self, id, endereco, bairro, cidade, uf, cep):
        self.id = id
        self.endereco = endereco
        self.bairro = bairro
        self.cidade = cidade
        self.uf = uf
        self.cep = cep